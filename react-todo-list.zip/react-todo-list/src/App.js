import ToDo from "./pages/todo";


function App() {
  return (
    <div>
      <ToDo/>
    </div>
  );
}

export default App;
